#define IDD_MESSAGES  6602
#define IDS_MESSAGE   6603
#define IDL_MESSAGE    100
